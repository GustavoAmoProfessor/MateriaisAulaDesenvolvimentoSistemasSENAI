public class TelaInsertionSort extends TelaBaseOrdenacao {

    public TelaInsertionSort() {
        super("Insertion Sort");

        btnOrdenar.addActionListener(e -> {
            try {
                int[] original = lerNumeros();
                int[] ordenado = original.clone();

                insertionSort(ordenado);

                mostrarResultado("Insertion Sort", original, ordenado);

            } catch (Exception erro) {
                mostrarErro();
            }
        });

        setVisible(true);
    }

    private void insertionSort(int[] vetor) {
        for (int i = 1; i < vetor.length; i++) {
            int chave = vetor[i];
            int j = i - 1;

            while (j >= 0 && vetor[j] > chave) {
                vetor[j + 1] = vetor[j];
                j--;
            }

            vetor[j + 1] = chave;
        }
    }
}