public class TelaSelectionSort extends TelaBaseOrdenacao {

    public TelaSelectionSort() {
        super("Selection Sort");

        btnOrdenar.addActionListener(e -> {
            try {
                int[] original = lerNumeros();
                int[] ordenado = original.clone();

                selectionSort(ordenado);

                mostrarResultado("Selection Sort", original, ordenado);

            } catch (Exception erro) {
                mostrarErro();
            }
        });

        setVisible(true);
    }

    private void selectionSort(int[] vetor) {
        for (int i = 0; i < vetor.length - 1; i++) {
            int menorIndice = i;

            for (int j = i + 1; j < vetor.length; j++) {
                if (vetor[j] < vetor[menorIndice]) {
                    menorIndice = j;
                }
            }

            int temp = vetor[i];
            vetor[i] = vetor[menorIndice];
            vetor[menorIndice] = temp;
        }
    }
}