import javax.swing.*;
import java.awt.*;

public class TelaMenu extends JFrame {

    public TelaMenu() {
        setTitle("Menu - Métodos de Ordenação");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1, 10, 10));

        JLabel titulo = new JLabel("Escolha o método de ordenação", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));

        JButton btnBubble = new JButton("Bubble Sort");
        JButton btnSelection = new JButton("Selection Sort");
        JButton btnInsertion = new JButton("Insertion Sort");

        add(titulo);
        add(btnBubble);
        add(btnSelection);
        add(btnInsertion);

        btnBubble.addActionListener(e -> {
            dispose();
            new TelaBubbleSort();
        });

        btnSelection.addActionListener(e -> {
            dispose();
            new TelaSelectionSort();
        });

        btnInsertion.addActionListener(e -> {
            dispose();
            new TelaInsertionSort();
        });

        setVisible(true);
    }
}