public class TelaBubbleSort extends TelaBaseOrdenacao {

    public TelaBubbleSort() {
        super("Bubble Sort");

        btnOrdenar.addActionListener(e -> {
            try {
                int[] original = lerNumeros();
                int[] ordenado = original.clone();

                bubbleSort(ordenado);

                mostrarResultado("Bubble Sort", original, ordenado);

            } catch (Exception erro) {
                mostrarErro();
            }
        });

        setVisible(true);
    }

    private void bubbleSort(int[] vetor) {
        for (int i = 0; i < vetor.length - 1; i++) {
            for (int j = 0; j < vetor.length - 1 - i; j++) {
                if (vetor[j] > vetor[j + 1]) {
                    int temp = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = temp;
                }
            }
        }
    }
}