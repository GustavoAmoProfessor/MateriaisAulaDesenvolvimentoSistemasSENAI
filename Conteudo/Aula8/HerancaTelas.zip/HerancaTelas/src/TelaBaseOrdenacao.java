import java.awt.*;
import java.util.Arrays;
import javax.swing.*;

public class TelaBaseOrdenacao extends JFrame {

    protected JLabel lblTitulo;
    protected JLabel lblEntrada;
    protected JTextField txtNumeros;

    protected JButton btnOrdenar;
    protected JButton btnLimpar;
    protected JButton btnVoltar;

    protected JTextArea txtResultado;

    protected JPanel painelPrincipal;
    protected JPanel painelBotoes;

    public TelaBaseOrdenacao(String tituloTela) {
        setTitle(tituloTela);
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        lblTitulo = new JLabel(tituloTela, JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));

        painelPrincipal = new JPanel();
        painelPrincipal.setLayout(new GridLayout(3, 1, 10, 10));
        painelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        lblEntrada = new JLabel("Digite os números separados por vírgula:");
        txtNumeros = new JTextField("8, 3, 5, 1, 9, 2");

        txtResultado = new JTextArea();
        txtResultado.setEditable(false);
        txtResultado.setFont(new Font("Monospaced", Font.PLAIN, 14));

        painelPrincipal.add(lblEntrada);
        painelPrincipal.add(txtNumeros);
        painelPrincipal.add(new JScrollPane(txtResultado));

        painelBotoes = new JPanel();

        btnOrdenar = new JButton("Ordenar");
        btnLimpar = new JButton("Limpar");
        btnVoltar = new JButton("Voltar");

        painelBotoes.add(btnOrdenar);
        painelBotoes.add(btnLimpar);
        painelBotoes.add(btnVoltar);

        add(lblTitulo, BorderLayout.NORTH);
        add(painelPrincipal, BorderLayout.CENTER);
        add(painelBotoes, BorderLayout.SOUTH);

        btnLimpar.addActionListener(e -> {
            txtNumeros.setText("");
            txtResultado.setText("");
        });

        btnVoltar.addActionListener(e -> {
            dispose();
            new TelaMenu();
        });
    }

    protected int[] lerNumeros() {
        String texto = txtNumeros.getText();
        String[] partes = texto.split(",");

        int[] numeros = new int[partes.length];

        for (int i = 0; i < partes.length; i++) {
            numeros[i] = Integer.parseInt(partes[i].trim());
        }

        return numeros;
    }

    protected void mostrarResultado(String algoritmo, int[] original, int[] ordenado) {
        txtResultado.setText(
                "Algoritmo: " + algoritmo + "\n\n" +
                "Vetor original: " + Arrays.toString(original) + "\n" +
                "Vetor ordenado: " + Arrays.toString(ordenado)
        );
    }

    protected void mostrarErro() {
        JOptionPane.showMessageDialog(
                this,
                "Digite apenas números separados por vírgula.\nExemplo: 8, 3, 5, 1",
                "Erro",
                JOptionPane.ERROR_MESSAGE
        );
    }
}