import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ExemploSwingPizzaria extends JFrame {

    private JComboBox<String> comboBox;
    private JRadioButton radioButton1, radioButton2;
    private JList<String> list;
    private JTextArea textArea;
    private ButtonGroup radioButtonGroup;

    public ExemploSwingPizzaria() {
        // Aplicando o tema personalizado para pizzaria
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Configuração do Frame
        setTitle("Menu de Pizzaria");
        setSize(450, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // JPanel para centralizar os componentes
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(255, 228, 196)); // Cor de fundo suave (bege claro)

        // Adicionando título com o tema
        JLabel titleLabel = new JLabel("Bem-vindo à Pizzaria!");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(new Color(255, 69, 0)); // Cor laranja, associada à pizza
        panel.add(titleLabel);

        // JComboBox - Escolher tipo de pizza
        String[] pizzaTypes = {"Escolha um tipo de pizza", "Margherita", "Pepperoni", "Frango com Catupiry", "Vegetariana"};
        comboBox = new JComboBox<>(pizzaTypes);
        comboBox.setBackground(new Color(255, 228, 196));
        panel.add(new JLabel("Escolha sua pizza:"));
        panel.add(comboBox);

        // JRadioButton - Tamanho da pizza
        radioButton1 = new JRadioButton("Pequena");
        radioButton2 = new JRadioButton("Grande");
        radioButtonGroup = new ButtonGroup();
        radioButtonGroup.add(radioButton1);
        radioButtonGroup.add(radioButton2);
        panel.add(new JLabel("Escolha o tamanho:"));
        panel.add(radioButton1);
        panel.add(radioButton2);

        // JList - Ingredientes adicionais
        String[] ingredients = {"Bacon", "Azeitona", "Cebola", "Pimentão", "Queijo Extra"};
        list = new JList<>(ingredients);
        list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        list.setBackground(new Color(255, 240, 200)); // Cor suave de fundo (semelhante ao molho de pizza)
        panel.add(new JLabel("Escolha os ingredientes adicionais:"));
        panel.add(new JScrollPane(list));

        // JTextArea - Comentários ou observações
        textArea = new JTextArea(5, 20);
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        textArea.setBackground(new Color(255, 239, 170)); // Cor suave que lembra uma massa de pizza
        panel.add(new JLabel("Observações ou Comentários:"));
        panel.add(new JScrollPane(textArea));

        // Botão para mostrar os resultados
        JButton showButton = new JButton("Confirmar Pedido");
        showButton.setBackground(new Color(255, 69, 0)); // Cor laranja vibrante, associada à pizza
        showButton.setForeground(Color.WHITE);
        panel.add(showButton);

        // Ação do botão
        showButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Pegando a seleção do JComboBox
                String selectedPizza = (String) comboBox.getSelectedItem();

                // Pegando a seleção do JRadioButton
                String selectedSize = radioButton1.isSelected() ? "Pequena" : radioButton2.isSelected() ? "Grande" : "Nenhum tamanho selecionado";

                // Pegando a seleção do JList
                String selectedIngredients = list.getSelectedValuesList().toString();

                // Pegando o conteúdo da JTextArea
                String comments = textArea.getText();

                // Exibindo os resultados
                String message = "Pizza escolhida: " + selectedPizza + "\n" +
                                 "Tamanho: " + selectedSize + "\n" +
                                 "Ingredientes adicionais: " + selectedIngredients + "\n" +
                                 "Comentários: " + comments;

                JOptionPane.showMessageDialog(null, message);
            }
        });

        // Adicionando o painel ao JFrame
        add(panel);

        // Tornar o frame visível
        setVisible(true);
    }

    public static void main(String[] args) {
        // Inicializa a interface gráfica
        new ExemploSwingPizzaria();
    }
}
