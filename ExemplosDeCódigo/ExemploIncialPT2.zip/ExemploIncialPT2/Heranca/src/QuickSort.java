public class QuickSort extends AlgoritmoOrdenacao {
    private int pivo;
    public QuickSort(int[] vetor) {
        super(vetor);
    }
    @Override
    public void ordenar() {
        quickSort(0, tamanho - 1);
    }
    private void quickSort(int inicio, int fim) {
        if (inicio < fim) {
            int indicePivo = particionar(inicio, fim);
            quickSort(inicio, indicePivo - 1);
            quickSort(indicePivo + 1, fim);
        }
    }
    private int particionar(int inicio, int fim) {
        pivo = vetor[fim];
        int i = inicio - 1;
        for (int j = inicio; j < fim; j++) {
            if (vetor[j] <= pivo) {
                i++;
                int temp = vetor[i];
                vetor[i] = vetor[j];
                vetor[j] = temp;
            }
        }
        int temp = vetor[i + 1];
        vetor[i + 1] = vetor[fim];
        vetor[fim] = temp;
        return i + 1;
    }
    public int definirPivo() {
        return pivo;
    }}