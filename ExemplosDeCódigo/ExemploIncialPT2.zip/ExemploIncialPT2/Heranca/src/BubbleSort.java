// Classe BubbleSort herdando da classe AlgoritmoOrdenacao
public class BubbleSort extends AlgoritmoOrdenacao {
    // Atributo exclusivo da classe
    private int trocas;
    // Construtor da classe
    public BubbleSort(int[] vetor) {
        // Chama o construtor da superclasse
        super(vetor);
        // Inicializa o contador de trocas
        trocas = 0;
    }
    // Sobrescrita do método ordenar()
    @Override
    public void ordenar() {
        // Estrutura principal do Bubble Sort
        for (int i = 0; i < tamanho - 1; i++) {
            for (int j = 0; j < tamanho - 1 - i; j++) {
                // Verifica se o número atual
                // é maior que o próximo
                if (vetor[j] > vetor[j + 1]) {
                    // Realiza a troca
                    int temp = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = temp;
                    // Incrementa contador de trocas
                    trocas++;
                }
            }
        }
    }
    // Retorna a quantidade de trocas realizadas
    public int contarTrocas() {
        return trocas;
    }}