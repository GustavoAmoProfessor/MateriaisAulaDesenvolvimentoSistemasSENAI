public class CombSort extends AlgoritmoOrdenacao {

    public CombSort(int[] vetor) {
        super(vetor);
    }

    @Override
    public void ordenar() {

        int gap = tamanho;
        boolean trocou = true;

        while (gap != 1 || trocou) {

            gap = (gap * 10) / 13;

            if (gap < 1) {
                gap = 1;
            }

            trocou = false;

            for (int i = 0; i < tamanho - gap; i++) {

                if (vetor[i] > vetor[i + gap]) {

                    int temp = vetor[i];
                    vetor[i] = vetor[i + gap];
                    vetor[i + gap] = temp;

                    trocou = true;
                }
            }
        }
    }
}