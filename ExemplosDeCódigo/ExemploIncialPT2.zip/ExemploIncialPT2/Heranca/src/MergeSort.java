public class MergeSort extends AlgoritmoOrdenacao {

    public MergeSort(int[] vetor) {
        super(vetor);
    }

    @Override
    public void ordenar() {
        ordenarMerge(0, tamanho - 1);
    }

    private void ordenarMerge(int inicio, int fim) {

        if (inicio < fim) {

            int meio = (inicio + fim) / 2;

            ordenarMerge(inicio, meio);
            ordenarMerge(meio + 1, fim);

            merge(inicio, meio, fim);
        }
    }

    private void merge(int inicio, int meio, int fim) {

        int[] auxiliar = new int[tamanho];

        for (int i = inicio; i <= fim; i++) {
            auxiliar[i] = vetor[i];
        }

        int esquerda = inicio;
        int direita = meio + 1;
        int atual = inicio;

        while (esquerda <= meio && direita <= fim) {

            if (auxiliar[esquerda] <= auxiliar[direita]) {
                vetor[atual] = auxiliar[esquerda];
                esquerda++;
            } else {
                vetor[atual] = auxiliar[direita];
                direita++;
            }

            atual++;
        }

        while (esquerda <= meio) {
            vetor[atual] = auxiliar[esquerda];
            esquerda++;
            atual++;
        }
    }
}