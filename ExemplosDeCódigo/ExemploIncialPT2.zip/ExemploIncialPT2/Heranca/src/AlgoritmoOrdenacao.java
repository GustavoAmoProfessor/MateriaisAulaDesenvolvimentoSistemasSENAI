// Classe responsável por representar
// um algoritmo genérico de ordenação
public class AlgoritmoOrdenacao implements Ordenavel {

    // Vetor que armazenará os números
    protected int[] vetor;

    // Variável responsável por armazenar
    // o tamanho do vetor
    protected int tamanho;

    // Método construtor da classe
    // Recebe um vetor por parâmetro
    public AlgoritmoOrdenacao(int[] vetor) {

        // Armazena o vetor recebido
        // no atributo da classe
        this.vetor = vetor;

        // Armazena o tamanho do vetor
        this.tamanho = vetor.length;
    }

    // Método definido na interface
    // Será sobrescrito pelas subclasses
    @Override
    public void ordenar() {

        // Método vazio
    }

    // Método responsável por exibir
    // os números armazenados no vetor
    @Override
    public String exibirVetor() {

        // Objeto utilizado para montar
        // a String de retorno
        StringBuilder resultado = new StringBuilder();

        // Percorre todos os números do vetor
        for (int numero : vetor) {

            // Adiciona o número na String
            resultado.append(numero)
                    .append(" ");
        }

        // Retorna o vetor formatado
        return resultado.toString();
    }
}