public interface Ordenavel {
    void ordenar();
    String exibirVetor();
}