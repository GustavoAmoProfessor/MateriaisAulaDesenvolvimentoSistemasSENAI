public class InsertionSort extends AlgoritmoOrdenacao {

    public InsertionSort(int[] vetor) {
        super(vetor);
    }

    @Override
    public void ordenar() {

        for (int i = 1; i < tamanho; i++) {

            int chave = vetor[i];
            int j = i - 1;

            while (j >= 0 && vetor[j] > chave) {
                vetor[j + 1] = vetor[j];
                j--;
            }

            vetor[j + 1] = chave;
        }
    }
}