public class SelectionSort extends AlgoritmoOrdenacao {
    private int comparacoes;
    public SelectionSort(int[] vetor) {
        super(vetor);
        comparacoes = 0;
    }

    @Override
    public void ordenar() {
        for (int i = 0; i < tamanho - 1; i++) {
        int menorIndice = i;
            for (int j = i + 1; j < tamanho; j++) {
                comparacoes++;
                if (vetor[j] < vetor[menorIndice]) {
                    menorIndice = j;
                }
            }
            int temp = vetor[i];
            vetor[i] = vetor[menorIndice];
            vetor[menorIndice] = temp;
        }
    }
    public int contarComparacoes() {
        return comparacoes;
    }
}