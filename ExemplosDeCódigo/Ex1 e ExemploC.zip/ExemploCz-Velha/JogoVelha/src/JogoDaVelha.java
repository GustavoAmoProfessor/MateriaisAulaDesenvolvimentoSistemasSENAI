// Importa classes gráficas do AWT, como BorderLayout, GridLayout e Font
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

// Classe principal do jogo.
// Herda de JFrame, ou seja, a janela principal da aplicação.
// Também implementa ActionListener para responder aos cliques dos botões.
public class JogoDaVelha extends JFrame implements ActionListener {

    // Matriz 3x3 de botões que representa o tabuleiro do jogo
    private JButton[][] botoes = new JButton[3][3];

    // Variável de controle de turno:
    // true = jogador X
    // false = jogador O
    private boolean turnoX = true;

    // Rótulo que mostra mensagens de status, como de quem é a vez ou quem venceu
    private JLabel status;

    // Construtor da classe: monta toda a interface do jogo
    public JogoDaVelha() {
        // Define o título da janela
        setTitle("Jogo da Velha");

        // Define o tamanho da janela
        setSize(400, 450);

        // Define que o programa será encerrado ao fechar a janela
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Centraliza a janela na tela
        setLocationRelativeTo(null);

        // Define o layout principal da janela como BorderLayout
        setLayout(new BorderLayout());

        // Cria o painel que vai conter o tabuleiro
        JPanel painelTabuleiro = new JPanel();

        // Define o layout do painel como uma grade 3x3
        painelTabuleiro.setLayout(new GridLayout(3, 3));

        // Define a fonte usada nos botões (X e O)
        Font fonte = new Font("Arial", Font.BOLD, 40);

        // Percorre a matriz para criar os 9 botões do tabuleiro
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                // Cria um botão vazio
                botoes[i][j] = new JButton("");

                // Define a fonte do texto do botão
                botoes[i][j].setFont(fonte);

                // Adiciona o listener para capturar clique nesse botão
                botoes[i][j].addActionListener(this);

                // Adiciona o botão no painel do tabuleiro
                painelTabuleiro.add(botoes[i][j]);
            }
        }

        // Cria o rótulo de status indicando quem começa jogando
        status = new JLabel("Vez do jogador: X", SwingConstants.CENTER);

        // Define a fonte do texto do status
        status.setFont(new Font("Arial", Font.BOLD, 20));

        // Cria o botão de reinício da partida
        JButton reiniciar = new JButton("Reiniciar");

        // Ao clicar em reiniciar, chama o método reiniciarJogo()
        reiniciar.addActionListener(e -> reiniciarJogo());

        // Adiciona o status na parte superior da janela
        add(status, BorderLayout.NORTH);

        // Adiciona o tabuleiro no centro da janela
        add(painelTabuleiro, BorderLayout.CENTER);

        // Adiciona o botão reiniciar na parte inferior
        add(reiniciar, BorderLayout.SOUTH);

        // Torna a janela visível
        setVisible(true);
    }

    // Método executado sempre que um botão do tabuleiro é clicado
    @Override
    public void actionPerformed(ActionEvent e) {
        // Obtém qual botão foi clicado
        JButton botao = (JButton) e.getSource();

        // Se o botão já tiver X ou O, não faz nada
        if (!botao.getText().equals("")) {
            return;
        }

        // Marca o botão com X ou O, dependendo do turno atual
        botao.setText(turnoX ? "X" : "O");

        // Verifica se houve vitória após a jogada
        if (verificarVitoria()) {
            // Atualiza a mensagem de status informando o vencedor
            status.setText("Jogador " + (turnoX ? "X" : "O") + " venceu!");

            // Desabilita todos os botões para encerrar a partida
            desabilitarBotoes();
        } 
        // Se ninguém venceu, verifica se o tabuleiro está cheio
        else if (tabuleiroCheio()) {
            // Caso esteja cheio e sem vencedor, é empate
            status.setText("Empate!");
        } 
        // Caso o jogo continue, troca o turno
        else {
            turnoX = !turnoX;

            // Atualiza a mensagem indicando de quem é a vez
            status.setText("Vez do jogador: " + (turnoX ? "X" : "O"));
        }
    }

    // Método que verifica se existe alguma condição de vitória no tabuleiro
    private boolean verificarVitoria() {
        // Verifica todas as linhas e colunas
        for (int i = 0; i < 3; i++) {
            // Verifica linha i
            if (igual(botoes[i][0], botoes[i][1], botoes[i][2])) return true;

            // Verifica coluna i
            if (igual(botoes[0][i], botoes[1][i], botoes[2][i])) return true;
        }

        // Verifica a diagonal principal
        if (igual(botoes[0][0], botoes[1][1], botoes[2][2])) return true;

        // Verifica a diagonal secundária
        if (igual(botoes[0][2], botoes[1][1], botoes[2][0])) return true;

        // Se nenhuma condição de vitória for encontrada, retorna false
        return false;
    }

    // Método auxiliar que verifica se três botões possuem o mesmo símbolo
    private boolean igual(JButton b1, JButton b2, JButton b3) {
        return !b1.getText().equals("") &&             // Garante que não estão vazios
               b1.getText().equals(b2.getText()) &&   // Compara b1 com b2
               b2.getText().equals(b3.getText());     // Compara b2 com b3
    }

    // Verifica se todas as posições do tabuleiro já foram preenchidas
    private boolean tabuleiroCheio() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                // Se encontrar algum botão vazio, o tabuleiro não está cheio
                if (botoes[i][j].getText().equals("")) {
                    return false;
                }
            }
        }

        // Se nenhum botão estiver vazio, o tabuleiro está cheio
        return true;
    }

    // Desabilita todos os botões do tabuleiro
    // Usado quando alguém vence
    private void desabilitarBotoes() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                botoes[i][j].setEnabled(false);
            }
        }
    }

    // Reinicia o jogo, limpando o tabuleiro e restaurando o turno inicial
    private void reiniciarJogo() {
        // Define novamente o jogador X como inicial
        turnoX = true;

        // Atualiza a mensagem de status
        status.setText("Vez do jogador: X");

        // Limpa todos os botões e os reabilita
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                botoes[i][j].setText("");
                botoes[i][j].setEnabled(true);
            }
        }
    }

    // Método principal que inicia o programa
    public static void main(String[] args) {
        // Garante que a interface gráfica seja criada na thread correta do Swing
        SwingUtilities.invokeLater(JogoDaVelha::new);
    }
}