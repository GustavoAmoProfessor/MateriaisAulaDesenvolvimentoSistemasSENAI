import java.awt.*;  // Biblioteca Swing
import java.awt.event.*;      // Layouts e componentes gráficos
import javax.swing.*; // Eventos (ActionListener)

public class App {


public class MinhaJanela {
    public static void main(String[] args) {
        // Criando a Janela
        JFrame frame = new JFrame("Minha Primeira Janela Swing");
        frame.setSize(400, 200); // Definindo tamanho
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout()); // Layout padrão
        
        // Criando um rótulo (JLabel)
        JLabel label = new JLabel("Clique no botão para mudar o texto!");
        
        // Criando um botão (JButton)
        JButton botao = new JButton("Clique Aqui");
        
        // Adicionando ação ao botão
        botao.addActionListener((ActionEvent e) -> {
            label.setText("Botão clicado! 🚀");
        });

        // Adicionando componentes à janela
        frame.add(label);
        frame.add(botao);

        // Tornando a janela visível
        frame.setVisible(true);
    }
}

}
