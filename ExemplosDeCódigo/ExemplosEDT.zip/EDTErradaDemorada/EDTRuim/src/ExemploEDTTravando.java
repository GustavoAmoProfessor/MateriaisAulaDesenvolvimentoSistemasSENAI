import javax.swing.*;
import java.awt.*;

public class ExemploEDTTravando extends JFrame {

    private JButton btnEnviar;
    private JLabel lblStatus;

    public ExemploEDTTravando() {

        setTitle("EDT Travando");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        lblStatus = new JLabel("Aguardando ação...");

        btnEnviar = new JButton("Executar");

        btnEnviar.addActionListener(e -> {

            lblStatus.setText("Processando...");

            // TAREFA MUITO PESADA
            for (long i = 0; i < 10_000_000_000L; i++) {

                Math.sqrt(i);

                // força ainda mais processamento
                if (i % 100000 == 0) {
                    System.out.println("Processando: " + i);
                }
            }

            lblStatus.setText("Finalizado");

            JOptionPane.showMessageDialog(null, "Fim");

        });

        add(lblStatus);
        add(btnEnviar);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new ExemploEDTTravando().setVisible(true);
        });

    }
}