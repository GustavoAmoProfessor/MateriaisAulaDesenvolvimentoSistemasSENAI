import javax.swing.*;
import java.awt.*;

public class ExemploBarraProgresso {
    public static void main(String[] args) {
        // Garantir que a interface gráfica seja criada na EDT
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                // Criando a janela principal
                JFrame frame = new JFrame("Exemplo Barra de Progresso");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setSize(400, 200);
                frame.setLayout(new BorderLayout());

                // Barra de progresso
                JProgressBar progressBar = new JProgressBar(0, 100);
                progressBar.setStringPainted(true); // Mostrar o texto de progresso
                frame.add(progressBar, BorderLayout.CENTER);

                // Botão para iniciar a tarefa
                JButton startButton = new JButton("Iniciar Tarefa");
                frame.add(startButton, BorderLayout.SOUTH);

                // Ação para iniciar a tarefa em outra thread
                startButton.addActionListener(e -> {
                    // Criando uma nova thread para a tarefa demorada
                    new Thread(new Task(progressBar)).start();
                });

                // Tornando a janela visível
                frame.setVisible(true);
            }
        });
    }

    // Tarefa demorada que será executada em uma thread separada
    static class Task implements Runnable {
        private final JProgressBar progressBar;

        public Task(JProgressBar progressBar) {
            this.progressBar = progressBar;
        }

        @Override
        public void run() {
            // Simulando uma tarefa demorada
            for (int i = 0; i <= 100; i++) {
                try {
                    Thread.sleep(100);  // Simulando tempo de execução
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                // Atualizando a barra de progresso na EDT
                final int progress = i;
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setValue(progress); // Atualiza a barra de progresso
                    }
                });
            }

            // Tarefa concluída
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    JOptionPane.showMessageDialog(null, "Tarefa Concluída!");
                }
            });
        }
    }
}

