import java.awt.*;
import javax.swing.*;

public class Main extends JFrame {
    private JTextField[] campos = new JTextField[10];
    private JTextArea areaBubble;
    private JTextArea areaSelection;
    private JTextArea areaQuick;
    public Main() {
        setTitle("Algoritmos de Ordenação");
        setSize(900, 560);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        JPanel painelPrincipal = new JPanel();
        painelPrincipal.setLayout(new BorderLayout(15, 15));
        painelPrincipal.setBorder(
                BorderFactory.createEmptyBorder(15, 20, 15, 20)
        );
        painelPrincipal.setBackground(
                new Color(235, 238, 242)
        );
        JLabel titulo = new JLabel(
                "Comparador de Algoritmos de Ordenação",
                SwingConstants.CENTER
        );
        titulo.setFont(
                new Font("Arial", Font.BOLD, 24)
        );
        titulo.setForeground(
                new Color(35, 55, 90)
        );
        JLabel subtitulo = new JLabel(
                "Digite 10 números inteiros",
                SwingConstants.CENTER
        );
        subtitulo.setFont(
                new Font("Arial", Font.PLAIN, 14)
        );
        JPanel painelTopo =
                new JPanel(new GridLayout(2, 1));

        painelTopo.setBackground(
                new Color(235, 238, 242)
        );
        painelTopo.add(titulo);
        painelTopo.add(subtitulo);
        JPanel painelEntrada =
                new JPanel(new BorderLayout(10, 10));

        painelEntrada.setBackground(Color.WHITE);
        painelEntrada.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(210, 215, 220)
                        ),
                        BorderFactory.createEmptyBorder(
                                15,
                                15,
                                15,
                                15
                        )
                )
        );
        JLabel tituloEntrada =
                new JLabel("Entrada dos números");
        tituloEntrada.setFont(
                new Font("Arial", Font.BOLD, 16)
        );
        JPanel painelCampos =
                new JPanel(new GridLayout(
                        2,
                        5,
                        10,
                        10
                ));
        painelCampos.setBackground(Color.WHITE);
        for (int i = 0; i < 10; i++) {
            JPanel blocoCampo =
                    new JPanel(new BorderLayout(4, 4));
            blocoCampo.setBackground(Color.WHITE);
            JLabel label =
                    new JLabel((i + 1) + "º número");
            label.setFont(
                    new Font("Arial", Font.BOLD, 12)
            );
            campos[i] = new JTextField();
            campos[i].setFont(
                    new Font("Arial", Font.PLAIN, 16)
            );
            campos[i].setHorizontalAlignment(
                    JTextField.CENTER
            );
            campos[i].setPreferredSize(
                    new Dimension(70, 35)
            );
            blocoCampo.add(label, BorderLayout.NORTH);
            blocoCampo.add(campos[i], BorderLayout.CENTER);
            painelCampos.add(blocoCampo);
        }
        painelEntrada.add(
                tituloEntrada,
                BorderLayout.NORTH
        );
        painelEntrada.add(
                painelCampos,
                BorderLayout.CENTER
        );
        JButton botaoOrdenar =
                new JButton("Executar");

        botaoOrdenar.setFont(
                new Font("Arial", Font.BOLD, 15)
        );
        botaoOrdenar.setBackground(
                new Color(35, 100, 180)
        );

        botaoOrdenar.setForeground(Color.WHITE);
        botaoOrdenar.setFocusPainted(false);
        botaoOrdenar.setPreferredSize(
                new Dimension(180, 40)
        );

        JButton botaoLimpar =
                new JButton("Limpar");
        botaoLimpar.setFont(
                new Font("Arial", Font.BOLD, 15)
        );
        botaoLimpar.setBackground(
                new Color(120, 120, 120)
        );

        botaoLimpar.setForeground(Color.WHITE);
        botaoLimpar.setFocusPainted(false);
        botaoLimpar.setPreferredSize(
                new Dimension(120, 40)
        );
        JPanel painelBotoes =
                new JPanel(new FlowLayout(
                        FlowLayout.CENTER,
                        15,
                        5
                ));

        painelBotoes.setBackground(
                new Color(235, 238, 242)
        );

        painelBotoes.add(botaoOrdenar);
        painelBotoes.add(botaoLimpar);

        areaBubble =
                criarAreaResultado("Bubble Sort");
        areaSelection =
                criarAreaResultado("Selection Sort");
        areaQuick =
                criarAreaResultado("Quick Sort");
        JPanel painelResultados =
                new JPanel(new GridLayout(1,3,12,12                ));
        painelResultados.setBackground(
                new Color(235, 238, 242)
        );
        painelResultados.add(
                criarCardResultado(areaBubble)
        );
        painelResultados.add(
                criarCardResultado(areaSelection)
        );
        painelResultados.add(
                criarCardResultado(areaQuick)
        );

        JPanel painelCentro = new JPanel();
        painelCentro.setLayout(
                new BoxLayout(painelCentro,BoxLayout.Y_AXIS
                )
        );
        painelCentro.setBackground(
                new Color(235, 238, 242)
        );
        painelCentro.add(painelEntrada);
        painelCentro.add(
                Box.createVerticalStrut(10)
        );
        painelCentro.add(painelBotoes);
        painelCentro.add(
                Box.createVerticalStrut(10)
        );
        painelCentro.add(painelResultados);
        painelPrincipal.add(
                painelTopo,
                BorderLayout.NORTH
        );
        painelPrincipal.add(
                painelCentro,
                BorderLayout.CENTER
        );
        add(painelPrincipal);
        botaoOrdenar.addActionListener(e -> executarOrdenacoes()
        );
        botaoLimpar.addActionListener(
                e -> limparCampos()
        );
        setVisible(true);
    }

    private JTextArea criarAreaResultado(
            String titulo
    ) {
        JTextArea area = new JTextArea();
        area.setFont(
                new Font("Consolas", Font.PLAIN, 14)
        );
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(
                BorderFactory.createTitledBorder(
                        titulo
                )
        );
        area.setBackground(
                new Color(250, 250, 250)
        );
        return area;
    }
    private JPanel criarCardResultado(
            JTextArea area
    ) {
        JPanel card =
                new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setPreferredSize(
                new Dimension(240, 180)
        );
        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(200, 205, 210)
                        ),
                        BorderFactory.createEmptyBorder(8,8,8,8
                        )
                )
        );
        card.add(
                new JScrollPane(area),
                BorderLayout.CENTER
        );
        return card;
    }
    private void executarOrdenacoes() {
       /* int[] numeros = new int[10];
        try {
            for (int i = 0; i < 10; i++) {
                numeros[i] =
                        Integer.parseInt(campos[i].getText()
                        );
            }
            BubbleSort bubble =
                    new BubbleSort(numeros.clone());
            bubble.ordenar();
            areaBubble.setText(
                    "Vetor:\n"
                            + bubble.exibirVetor()
                            + "\n\nTrocas:\n"
                            + bubble.contarTrocas()
            );
            SelectionSort selection =
                    new SelectionSort(numeros.clone());

            selection.ordenar();
            areaSelection.setText(
                    "Vetor:\n"+ selection.exibirVetor()+ "\n\nComparações:\n"+ selection.contarComparacoes()
            );
            QuickSort quick =
                    new QuickSort(numeros.clone());

            quick.ordenar();
            areaQuick.setText(
                    "Vetor:\n"
                            + quick.exibirVetor()
                            + "\n\nPivô:\n"
                            + quick.definirPivo()
            );

        } catch (NumberFormatException erro) {
            JOptionPane.showMessageDialog(
                    null,
                    "Digite apenas números inteiros."
            );
        }*/
    }
    private void limparCampos() {
        for (JTextField campo : campos) {
            campo.setText("");
        }
        areaBubble.setText("");
        areaSelection.setText("");
        areaQuick.setText("");
        campos[0].requestFocus();
    }
    public static void main(String[] args) {
        new Main();
    }
}