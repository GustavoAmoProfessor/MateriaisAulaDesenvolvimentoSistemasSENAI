public class AlgoritmoOrdenacao {

    protected int[] vetor;
    protected int tamanho;

    public AlgoritmoOrdenacao(int[] vetor) {

        this.vetor = vetor;
        this.tamanho = vetor.length;
    }

    public void ordenar() {

    }

    public String exibirVetor() {

        StringBuilder resultado = new StringBuilder();

        for (int numero : vetor) {
            resultado.append(numero).append(" ");
        }

        return resultado.toString();
    }
}